FactoryBot.define do
  factory :platform_app do
    name { Faker::Book.name }
  end
end
