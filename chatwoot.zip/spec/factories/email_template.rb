FactoryBot.define do
  factory :email_template do
    name { 'MyString' }
  end
end
