FactoryBot.define do
  factory :installation_config do
    name { 'xyc' }
    value { 1.5 }
    locked { true }
  end
end
