FactoryBot.define do
  factory :portal_member do
    portal
    user
  end
end
