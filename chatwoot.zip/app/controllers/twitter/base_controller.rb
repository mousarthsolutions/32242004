class Twitter::BaseController < ApplicationController
  include TwitterConcern
end
