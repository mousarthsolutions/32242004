require 'administrate/field/base'

class SecretField < Administrate::Field::String
end
