class Api::V1::Accounts::EnterpriseAccountsController < Api::V1::Accounts::BaseController
end
